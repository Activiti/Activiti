package org.activiti;

import java.text.ParseException;

public class EmergencyCallCenterApp {

  public static void main(String[] args) throws ParseException {
	  System.out.println("EmergencyCallCenterApp.");
  }

}
